# Pattern: <navn>
**Når bruke:** …  •  **Ikke bruk når:** …  •  **Kontekst:** @cloud/@onprem/@PII

## Steg-for-steg
1) …
2) …

## Språkvarianter
### TypeScript/Node (Next.js)
```ts
// eksempel
```

### Python (FastAPI)
```py
# eksempel
```

### Java (Spring)
```java
// eksempel
```

## Ytelse/Sikkerhet
Forventet latens/kost/SLO; trusselflate; hardening-sjekkliste.

## Observability
Logg-/trace-nøkler, eksempel-spørringer.

## Vanlige feil / Anti-mønstre
- …
