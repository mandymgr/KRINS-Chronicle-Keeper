# ADR-0007: Implement API Rate Limiting Pattern
**Dato:** 2025-08-30  •  **Komponent:** unknown  •  **Eier:** @mandymgr

## Problem
Beskriv bruker-/operasjonsproblemet, og legg ved målbare symptomer (tall/kilder).

## Alternativer
1) <Alternativ A> – fordeler/ulemper (sikkerhet/ytelse/kost/risiko)
2) <Alternativ B> – …
3) <Do nothing> – konsekvens

## Beslutning
Valgt: <A/B/...>. Begrunnelse (maks 5 linjer). Rollback-plan (hvordan og når).

## Evidens (før/etter)
Før: <tall, kilder>  •  Etter (forventet/observert): <tall, kilder>

## Lenker
PR: #...  •  Runbook: /docs/runbooks/<id>.md  •  Metrikker: <Grafana/Query>  •  Issue/Incident: #...
