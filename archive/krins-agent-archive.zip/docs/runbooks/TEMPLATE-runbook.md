# Runbook: <navn>
**Trigger:** <alarm/hendelse>  •  **Eier:** <team/person>  •  **SLA/SLO:** <verdier>

## Sjekkliste (MTTR-fokus)
- [ ] Bekreft påvirkning og scope
- [ ] Sjekk metrikker/alerts (lenker)
- [ ] Kjør diagnose-kommandoer/spørringer
- [ ] Midlertidig mitigasjon
- [ ] Rotårsaksanalyse / varig fix

## Observability
- Dashboards
- Logg/trace søkestrenger
- Feature flags / toggles

## Eskalering
- Primær → Sekundær → Leder
- Eksterne avhengigheter og kontaktpunkter
