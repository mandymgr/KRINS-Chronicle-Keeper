import React from 'react';
import PatternDiscovery from './PatternDiscovery';

export default function PatternBrowser() {
  return <PatternDiscovery />;
}